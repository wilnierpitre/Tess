package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class CitasActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton btnFecha;
    Button btnAgendar;
    TextView fechaseleccionada;
    Spinner spinner_cita,spinner_doc;
    EditText descripcion;
    String fecha_cita ,spiner_cita,spiner_doc,descrip,respuesta,fecha_cita_selec;
    Integer id;
    private int dia,mes,ano;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_citas);

        descripcion= findViewById(R.id.descripcion);
        btnFecha = findViewById(R.id.btncalendar);
        fechaseleccionada= findViewById(R.id.fechaSeleccionada);
        spinner_cita= findViewById(R.id.cita_spiner);
        spinner_doc = findViewById(R.id.medico_spiner);
        btnAgendar = findViewById(R.id.btnAgendar);

        btnFecha.setOnClickListener(this);


        ArrayAdapter<CharSequence> adapter_doc = ArrayAdapter.createFromResource(this,R.array.medico, android.R.layout.simple_spinner_item);
        ArrayAdapter<CharSequence> adapter_cita = ArrayAdapter.createFromResource(this,R.array.tipo_cita, android.R.layout.simple_spinner_item);
        spinner_cita.setAdapter(adapter_cita);
        spinner_doc.setAdapter(adapter_doc);

        recuperarDatos();
        btnAgendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RegistrarCita("https://ingenierohorta.000webhostapp.com/pet/guardar_cita.php");
            }
        });
    }



    @Override
    public void onClick(View v) {
        if(v==btnFecha){
            final Calendar c = Calendar.getInstance();
            dia = c.get(Calendar.DAY_OF_MONTH);
            mes = c.get(Calendar.MONTH);
            ano = c.get(Calendar.YEAR);

            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                    fecha_cita= dayOfMonth+"/"+(month+1)+"/"+year;
                    fechaseleccionada.setText(fecha_cita);
                }
            },dia,mes,ano);
            datePickerDialog.show();

        }
    }

    private void recuperarDatos(){
        SharedPreferences preferences= getSharedPreferences("preferenciasLogin", Context.MODE_PRIVATE);
        //id= preferences.getInt("id", Integer.parseInt("0"));
        id =preferences.getInt("id", Integer.parseInt("0"));
    }

    private void RegistrarCita(String URL){
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (!response.isEmpty()){
                    //Toast.makeText(CitasActivity.this,response,Toast.LENGTH_LONG).show();

                    try {
                        JSONObject jsonObjectAc = new JSONObject(response);
                        respuesta  = jsonObjectAc.getString("respuesta");


                            if (respuesta.isEmpty()){
                                Toast.makeText(CitasActivity.this,"No se permiten campos vacios",Toast.LENGTH_LONG).show();
                            }else{
                                Toast.makeText(CitasActivity.this,respuesta,Toast.LENGTH_LONG).show();
                                Intent miIntent = new Intent(getApplicationContext(),PresentacionActivity.class);
                                startActivity(miIntent);
                            }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }



                }else{


                    Intent miIntent = new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(miIntent);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(CitasActivity.this,error.toString(),Toast.LENGTH_LONG).show();
        }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros = new HashMap<String, String>();


                spiner_cita = spinner_cita.getSelectedItem().toString();
                spiner_doc = spinner_doc.getSelectedItem().toString();
                descrip= descripcion.getText().toString();
                fecha_cita_selec= fechaseleccionada.getText().toString();
                /*if (!spiner_cita.isEmpty() || !spiner_doc.isEmpty() || !descrip.isEmpty() || !fecha_cita.isEmpty()){


                }else{



                }*/
                parametros.put("tipo_cita",spiner_cita);
                parametros.put("medico_cita",spiner_doc);
                parametros.put("fecha_cita",fecha_cita_selec);
                parametros.put("descripcion_problema",descrip);
                parametros.put("id",id.toString());


                return parametros;


            }

        };
        RequestQueue requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);



    }
}